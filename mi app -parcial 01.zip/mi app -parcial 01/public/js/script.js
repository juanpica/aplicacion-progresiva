async function cargarImagenes() {
    try {
        const response = await fetch('https://6707d1938e86a8d9e42d0fb3.mockapi.io/image');
        const imagenes = await response.json();
        console.log(imagenes);

        const reel = document.getElementById('reel');
        reel.innerHTML = ''; 

        imagenes.forEach(imagen => {
            const card = document.createElement('div');
            card.classList.add('card', 'col-md-3');
            card.style.width = '18rem'; 
            
            card.innerHTML = `
                <img src="${imagen.url}" class="card-img-top" alt="${imagen.titulo}">
                <div class="card-body">
                    <h5 class="card-title">${imagen.titulo}</h5>
                    <p class="card-text">Fecha: ${new Date(imagen.fecha).toLocaleString()}</p>
                    <a href="#" class="btn btn-primary">Ver más</a>
                </div>
            `;
            reel.appendChild(card);
        });
    } catch (error) {
        console.error('Error al cargar las imágenes:', error);
    }
}

document.addEventListener('DOMContentLoaded', cargarImagenes);
