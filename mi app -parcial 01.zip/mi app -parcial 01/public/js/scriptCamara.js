const entradaArchivo = document.getElementById('input-file');
const vistaPrevia = document.getElementById('preview');
const btnConfirmar = document.getElementById('btn-confirmar');
const btnEliminar = document.getElementById('btn-eliminar'); 
const btnVerMas = document.getElementById('btn-ver-mas'); 
const modal = document.getElementById('modal');
const largeImage = document.getElementById('large-image');
const btnClose = document.getElementById('btn-close');


entradaArchivo.addEventListener('change', (evento) => {
    const archivo = evento.target.files[0];
    if (archivo) {
        if (archivo.size > 2000000) {
            alert('La foto es muy grande, que no supere los 2MB.');
            return;
        }

        const lector = new FileReader();
        lector.onload = (e) => {
            vistaPrevia.src = e.target.result; 
            vistaPrevia.style.display = 'block'; 
            btnEliminar.style.display = 'inline-block'; 
            btnVerMas.style.display = 'inline-block'; 
        };
        lector.readAsDataURL(archivo); 
    }
});


btnEliminar.addEventListener('click', () => {
    entradaArchivo.value = '';
    vistaPrevia.style.display = 'none'; 
    btnEliminar.style.display = 'none';
    btnVerMas.style.display = 'none'; 
});


btnVerMas.addEventListener('click', () => {
    largeImage.src = vistaPrevia.src; 
    modal.style.display = 'block';
});


btnClose.addEventListener('click', () => {
    modal.style.display = 'none'; 
});


btnConfirmar.addEventListener('click', async () => {
    const titulo = document.getElementById('titulo').value;
    const imagenBase64 = vistaPrevia.src;

    if (!titulo || !imagenBase64) {
        alert('Por favor completa todos los campos.');
        return;
    }

    const datos = {
        titulo: titulo,
        url: imagenBase64,
        fecha: new Date().toISOString() 
    };

    console.log('Datos a enviar:', datos); 

    try {
        const respuesta = await fetch('https://6707d1938e86a8d9e42d0fb3.mockapi.io/image', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(datos) 
        });

        if (respuesta.ok) {
            alert('Foto publicada con éxito');
            window.location.href = 'index.html'; 
        } else {
            const errorText = await respuesta.text();
            alert(`Error al publicar la foto: ${errorText}`); 
        }
    } catch (error) {
        console.error('Error al publicar la foto:', error);
        alert('Error al publicar la foto...');
    }
});



